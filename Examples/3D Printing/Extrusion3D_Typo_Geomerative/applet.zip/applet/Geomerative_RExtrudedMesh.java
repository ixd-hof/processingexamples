import processing.core.*; 
import processing.xml.*; 

import processing.opengl.*; 
import geomerative.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class Geomerative_RExtrudedMesh extends PApplet {




RFont f;
RShape grp;
RExtrudedMesh em;

public void setup() {
  size(600, 400, OPENGL);

  // VERY IMPORTANT: Allways initialize the library in the setup
  RG.init(this);

  //  Load the font file we want to use (the file must be in the data folder in the sketch floder), with the size 60 and the alignment CENTER
  grp = RG.getText("Depth!", "FreeSans.ttf", 50, CENTER);
  
  // Set the polygonizer detail (lower = more details)
  RG.setPolygonizer(RG.UNIFORMLENGTH);
  RG.setPolygonizerLength(1);
  
  // Geomerative's flat mesh
  //RMesh m = grp.toMesh();
  
  // Create an extruded mesh
  em = new RExtrudedMesh(grp, 20);

  // Enable smoothing
  smooth();
}

public void draw()
{
  background(100);

  lights();

  translate(width/2, height/2, 200);
  rotateY(millis()/2000.0f);

  fill(255, 100, 0);
  noStroke();
  
  // Draw mesh
  em.draw();
}
class RExtrudedMesh
{
  float depth = 10;
  RPoint[][] points;
  RMesh m;
  
  RExtrudedMesh(RShape grp, float d)
  {
    depth = d;
    m = grp.toMesh();
    points = grp.getPointsInPaths();
  }
  
  public void draw()
  {
    // Draw front
  for (int i=0; i<m.countStrips(); i++) {
    beginShape(PConstants.TRIANGLE_STRIP);
    for (int j=0;j<m.strips[i].vertices.length;j++) {
      vertex(m.strips[i].vertices[j].x, m.strips[i].vertices[j].y, 0);
    }
    endShape(PConstants.CLOSE);
  }

  // Draw back
  for (int i=0; i<m.countStrips(); i++) {
    beginShape(PConstants.TRIANGLE_STRIP);
    for (int j=0;j<m.strips[i].vertices.length;j++) {
      vertex(m.strips[i].vertices[j].x, m.strips[i].vertices[j].y, -depth);
    }
    endShape(PConstants.CLOSE);
  }
  
  // Draw side (from outline points)
  for (int i=0; i<points.length; i++) {
    beginShape(PConstants.TRIANGLE_STRIP);
    for (int j=0; j<points[i].length-1; j++)
    {
      vertex(points[i][j].x, points[i][j].y, 0);
      vertex(points[i][j].x, points[i][j].y, -depth);
      vertex(points[i][j+1].x, points[i][j+1].y, -depth);
      vertex(points[i][j].x, points[i][j].y, 0);
      vertex(points[i][j+1].x, points[i][j+1].y, 0);
    }
    vertex(points[i][0].x, points[i][0].y, 0);
    endShape(PConstants.CLOSE);
  }
  }
}
  static public void main(String args[]) {
    PApplet.main(new String[] { "--present", "--bgcolor=#000000", "--stop-color=#cccccc", "Geomerative_RExtrudedMesh" });
  }
}
